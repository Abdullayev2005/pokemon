import AllPokemonData from './AllPokemonData/AllPokemonData';

const Home = () => {
    return (
        <div>
            <AllPokemonData/>
            
        </div>
    );
};

export default Home;